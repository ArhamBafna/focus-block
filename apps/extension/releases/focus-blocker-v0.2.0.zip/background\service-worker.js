const ALARM_SESSION_EXPIRY = "focus_session_expiry";
const ALARM_SCHEDULE_BOUNDARY = "focus_schedule_boundary";
const ALARM_TEMP_ALLOW_EXPIRY = "focus_temp_allow_expiry";
const BASE_RULE_ID = 1;
const BLOCKED_PAGE_PATH = "blocked/index.html";
function storageGet(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (result) => {
      resolve(result[key]);
    });
  });
}
function storageSet(key, value) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [key]: value }, resolve);
  });
}
function storageGetRaw(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (result) => resolve(result[key]));
  });
}
async function setIfChanged(key, value) {
  const current = await storageGet(key);
  if (JSON.stringify(current) === JSON.stringify(value)) return false;
  await storageSet(key, value);
  return true;
}
let mutationTail = Promise.resolve();
function withLock(task) {
  const run = mutationTail.then(task, task);
  mutationTail = run.then(
    () => void 0,
    () => void 0
  );
  return run;
}
let reconcileRequested = false;
function requestReconcile() {
  reconcileRequested = true;
  return withLock(async () => {
    while (reconcileRequested) {
      reconcileRequested = false;
      try {
        await applyBlockingState();
      } catch (error) {
        console.error("[FocusBlocker] Reconcile pass failed:", error);
      }
    }
  });
}
const SAFE_DOMAIN_CHARS = /^[a-z0-9.-]+$/;
function isValidStoredDomain(domain) {
  if (typeof domain !== "string") return false;
  const str = domain.toLowerCase();
  if (str.startsWith("*")) {
    const matchText = str.slice(1);
    return matchText.length > 0 && SAFE_DOMAIN_CHARS.test(matchText);
  }
  return str.includes(".") && SAFE_DOMAIN_CHARS.test(str);
}
function escapeRegex(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function addDomainRules(rules, domain, priority, action, nextId) {
  if (!isValidStoredDomain(domain)) {
    if (domain) console.warn(`[FocusBlocker] Skipping invalid stored entry: ${JSON.stringify(domain)}`);
    return nextId;
  }
  const resourceTypes = [chrome.declarativeNetRequest.ResourceType.MAIN_FRAME];
  if (domain.startsWith("*")) {
    const matchText = domain.slice(1);
    let ruleAction = action;
    let condition = { urlFilter: `*${matchText}*`, resourceTypes };
    if (action.type === chrome.declarativeNetRequest.RuleActionType.REDIRECT && action.redirect?.url) {
      const regexStr = `^https?://.*${escapeRegex(matchText)}.*`;
      ruleAction = {
        type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
        redirect: {
          regexSubstitution: `${action.redirect.url}?url=\\0`
        }
      };
      condition = { regexFilter: regexStr, resourceTypes };
    }
    rules.push({
      id: nextId++,
      priority,
      action: ruleAction,
      condition
    });
    return nextId;
  }
  for (const urlFilter of [`||${domain}^`, `||www.${domain}^`]) {
    let ruleAction = action;
    let condition = { urlFilter, resourceTypes };
    if (action.type === chrome.declarativeNetRequest.RuleActionType.REDIRECT && action.redirect?.url) {
      const isWww = urlFilter.startsWith("||www.");
      const exactDomain = isWww ? `www.${domain}` : domain;
      const regexStr = `^https?://([^/]*\\.)?(${escapeRegex(exactDomain)})(/.*)?$`;
      ruleAction = {
        type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
        redirect: {
          regexSubstitution: `${action.redirect.url}?url=\\0`
        }
      };
      condition = { regexFilter: regexStr, resourceTypes };
    }
    rules.push({
      id: nextId++,
      priority,
      action: ruleAction,
      condition
    });
  }
  return nextId;
}
function buildRules(blocklist, whitelist, temporaryAllows, extensionId) {
  const blockedPageUrl = `chrome-extension://${extensionId}/${BLOCKED_PAGE_PATH}`;
  const rules = [];
  let id = BASE_RULE_ID;
  for (const domain of whitelist) {
    id = addDomainRules(rules, domain, 2, { type: chrome.declarativeNetRequest.RuleActionType.ALLOW }, id);
  }
  for (const domain of temporaryAllows) {
    id = addDomainRules(rules, domain, 3, { type: chrome.declarativeNetRequest.RuleActionType.ALLOW }, id);
  }
  for (const domain of blocklist) {
    id = addDomainRules(rules, domain, 1, {
      type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
      redirect: { url: blockedPageUrl }
    }, id);
  }
  return rules;
}
function buildLockdownRules(whitelist, temporaryAllows, extensionId) {
  const blockedPageUrl = `chrome-extension://${extensionId}/${BLOCKED_PAGE_PATH}`;
  const rules = [];
  let id = BASE_RULE_ID;
  for (const domain of whitelist) {
    id = addDomainRules(rules, domain, 2, { type: chrome.declarativeNetRequest.RuleActionType.ALLOW }, id);
  }
  for (const domain of temporaryAllows) {
    id = addDomainRules(rules, domain, 3, { type: chrome.declarativeNetRequest.RuleActionType.ALLOW }, id);
  }
  rules.push({
    id: id++,
    priority: 2,
    action: { type: chrome.declarativeNetRequest.RuleActionType.ALLOW },
    condition: {
      urlFilter: `chrome-extension://${extensionId}/*`,
      resourceTypes: [chrome.declarativeNetRequest.ResourceType.MAIN_FRAME]
    }
  });
  rules.push({
    id: id++,
    priority: 1,
    action: {
      type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
      redirect: { url: blockedPageUrl }
    },
    condition: {
      resourceTypes: [chrome.declarativeNetRequest.ResourceType.MAIN_FRAME]
    }
  });
  return rules;
}
let lastRulesJson = null;
async function updateBlockingRules(newRules) {
  const json = JSON.stringify(newRules);
  if (json === lastRulesJson) return;
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const existingIds = existing.map((r) => r.id);
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: existingIds,
    addRules: newRules
  });
  lastRulesJson = json;
  /* @__PURE__ */ (() => {
  })(
    `[FocusBlocker] Rules updated: removed ${existingIds.length}, added ${newRules.length}`
  );
}
async function clearAllRules() {
  await updateBlockingRules([]);
}
async function getActiveTemporaryAllows() {
  const entries = await storageGet("temporary_allowlist");
  const now = Date.now();
  const active = (Array.isArray(entries) ? entries : []).filter(
    (entry) => typeof entry?.id === "string" && typeof entry.domain === "string" && typeof entry.expires_at === "number" && entry.expires_at > now
  );
  if (active.length !== (entries?.length ?? 0)) {
    await setIfChanged("temporary_allowlist", active);
  }
  return active;
}
async function scheduleTemporaryAllowExpiry(entries) {
  await chrome.alarms.clear(ALARM_TEMP_ALLOW_EXPIRY);
  const nextExpiry = entries.reduce(
    (next, entry) => next === null || entry.expires_at < next ? entry.expires_at : next,
    null
  );
  if (nextExpiry !== null) {
    await chrome.alarms.create(ALARM_TEMP_ALLOW_EXPIRY, { when: nextExpiry });
  }
}
function timeToMinutes(value) {
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) return null;
  const [hours, minutes] = value.split(":").map(Number);
  return hours * 60 + minutes;
}
function localDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
function scheduleDays(schedule) {
  const days = Array.isArray(schedule.days_of_week) ? [...new Set(schedule.days_of_week.filter((day) => Number.isInteger(day) && day >= 0 && day <= 6))] : [];
  return days.length > 0 ? days : [0, 1, 2, 3, 4, 5, 6];
}
function scheduleRunsOn(schedule, day) {
  const endsOn = typeof schedule.ends_on === "string" ? schedule.ends_on : null;
  return scheduleDays(schedule).includes(day.getDay()) && (endsOn === null || localDateKey(day) <= endsOn);
}
function getCurrentSchedule(schedules, now = /* @__PURE__ */ new Date()) {
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  return schedules.find((schedule) => {
    const start = timeToMinutes(schedule.start_time);
    const end = timeToMinutes(schedule.end_time);
    return scheduleRunsOn(schedule, now) && start !== null && end !== null && start < end && currentMinutes >= start && currentMinutes < end;
  }) ?? null;
}
function getScheduleBoundary(schedule, key, day) {
  const minutes = timeToMinutes(schedule[key]);
  if (minutes === null) return null;
  const boundary = new Date(day);
  boundary.setHours(Math.floor(minutes / 60), minutes % 60, 0, 0);
  return boundary;
}
function computeScheduleSuppression(endMinutes, plannedDurationSec, now) {
  if (endMinutes === null) return now.getTime() + plannedDurationSec * 1e3;
  const scheduledEnd = new Date(now);
  scheduledEnd.setHours(Math.floor(endMinutes / 60), endMinutes % 60, 0, 0);
  const wallMinutes = scheduledEnd.getHours() * 60 + scheduledEnd.getMinutes();
  if (wallMinutes !== endMinutes) {
    scheduledEnd.setHours(Math.floor(endMinutes / 60) + 1, 0, 0, 0);
  }
  return scheduledEnd.getTime() > now.getTime() ? scheduledEnd.getTime() : now.getTime() + plannedDurationSec * 1e3;
}
async function scheduleNextBoundaryAlarm(schedules) {
  await chrome.alarms.clear(ALARM_SCHEDULE_BOUNDARY);
  if (schedules.length === 0) return;
  const now = /* @__PURE__ */ new Date();
  const candidates = [];
  for (let offset = 0; offset <= 7; offset += 1) {
    const day = new Date(now);
    day.setDate(now.getDate() + offset);
    for (const schedule of schedules) {
      if (!scheduleRunsOn(schedule, day)) continue;
      const start = getScheduleBoundary(schedule, "start_time", day);
      const end = getScheduleBoundary(schedule, "end_time", day);
      if (start && start.getTime() > Date.now() + 500) candidates.push(start);
      if (end && end.getTime() > Date.now() + 500) candidates.push(end);
    }
  }
  const nextBoundary = candidates.sort((a, b) => a.getTime() - b.getTime())[0];
  if (nextBoundary) {
    await chrome.alarms.create(ALARM_SCHEDULE_BOUNDARY, { when: nextBoundary.getTime() });
  }
}
async function pushHistory(archived) {
  const rawHistory = await storageGet("history");
  const history = Array.isArray(rawHistory) ? rawHistory : [];
  history.unshift(archived);
  await storageSet("history", history);
}
async function finalizeActiveSession(outcome) {
  const session = await storageGet("active_session");
  if (!session) return null;
  const archived = {
    ...session,
    status: outcome,
    ended_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  await pushHistory(archived);
  await storageSet("active_session", null);
  return archived;
}
function isActiveSessionShape(value) {
  if (!value || typeof value !== "object") return false;
  const v = value;
  return typeof v.id === "string" && v.status === "active" && (v.mode === "blocklist" || v.mode === "lockdown") && typeof v.started_at === "string" && typeof v.planned_duration_sec === "number" && Array.isArray(v.blocklist_snapshot) && Array.isArray(v.whitelist_snapshot);
}
async function migrateStrayActiveSession() {
  const value = await storageGetRaw("active_session");
  if (value === void 0 || value === null) return null;
  if (isActiveSessionShape(value)) {
    return { ...value, status: "active", ended_at: null };
  }
  const stray = value;
  if (stray.status !== "completed" && stray.status !== "stopped") {
    console.warn("[FocusBlocker] Unrecognizable record in active slot; discarding.");
    await storageSet("active_session", null);
    return null;
  }
  console.warn("[FocusBlocker] Stray terminal record in active slot; archiving.");
  const archived = {
    id: typeof stray.id === "string" ? stray.id : `stray-${Date.now()}`,
    preset_id: typeof stray.preset_id === "string" ? stray.preset_id : null,
    mode: stray.mode === "lockdown" ? "lockdown" : "blocklist",
    started_at: typeof stray.started_at === "string" ? stray.started_at : (/* @__PURE__ */ new Date()).toISOString(),
    planned_duration_sec: typeof stray.planned_duration_sec === "number" ? stray.planned_duration_sec : 0,
    blocklist_snapshot: Array.isArray(stray.blocklist_snapshot) ? stray.blocklist_snapshot : [],
    whitelist_snapshot: Array.isArray(stray.whitelist_snapshot) ? stray.whitelist_snapshot : [],
    scheduled_schedule_id: typeof stray.scheduled_schedule_id === "string" ? stray.scheduled_schedule_id : null,
    status: stray.status,
    ended_at: typeof stray.ended_at === "string" ? stray.ended_at : (/* @__PURE__ */ new Date()).toISOString()
  };
  await pushHistory(archived);
  await storageSet("active_session", null);
  await clearAllRules();
  await chrome.alarms.clear(ALARM_SESSION_EXPIRY);
  return null;
}
async function activateScheduledSession(schedule, now) {
  const active = await storageGet("active_session");
  if (active) {
    await finalizeActiveSession("stopped");
  }
  const blocklist = (await storageGet("blocklist") ?? []).map((entry) => entry.domain);
  const whitelist = (await storageGet("whitelist") ?? []).map((entry) => entry.domain);
  const end = getScheduleBoundary(schedule, "end_time", now);
  const remaining = end ? Math.max(1, Math.ceil((end.getTime() - now.getTime()) / 1e3)) : 1;
  const session = {
    id: `scheduled-${schedule.id}-${now.getTime()}`,
    preset_id: null,
    mode: schedule.mode,
    started_at: now.toISOString(),
    ended_at: null,
    planned_duration_sec: remaining,
    status: "active",
    blocklist_snapshot: blocklist,
    whitelist_snapshot: whitelist,
    scheduled_schedule_id: schedule.id
  };
  await storageSet("active_session", session);
  return session;
}
async function expireSession() {
  const session = await storageGet("active_session");
  if (!session) return;
  if (!session.scheduled_schedule_id) {
    const elapsed = Math.floor((Date.now() - new Date(session.started_at).getTime()) / 1e3);
    if (elapsed < session.planned_duration_sec) return;
  }
  const outcome = await scheduledSessionOutcome(session.scheduled_schedule_id ?? null);
  await finalizeActiveSession(outcome);
  await clearAllRules();
  await chrome.alarms.clear(ALARM_SESSION_EXPIRY);
  /* @__PURE__ */ (() => {
  })("[FocusBlocker] Session expired, blocking rules cleared.");
}
async function scheduledSessionOutcome(scheduledId) {
  if (!scheduledId) return "completed";
  const schedules = await storageGet("schedules") ?? [];
  return schedules.some((schedule) => schedule.id === scheduledId) ? "completed" : "cancelled";
}
async function applyBlockingState() {
  const schedules = await storageGet("schedules") ?? [];
  await scheduleNextBoundaryAlarm(schedules);
  const temporaryAllows = await getActiveTemporaryAllows();
  await scheduleTemporaryAllowExpiry(temporaryAllows);
  const suppressedUntil = await storageGet("schedule_suppressed_until");
  const scheduleSuppressed = typeof suppressedUntil === "number" && suppressedUntil > Date.now();
  if (typeof suppressedUntil === "number" && !scheduleSuppressed) {
    await setIfChanged("schedule_suppressed_until", null);
  }
  const currentSchedule = scheduleSuppressed ? null : getCurrentSchedule(schedules);
  let session = await migrateStrayActiveSession();
  if (currentSchedule) {
    if (!session || session.scheduled_schedule_id !== currentSchedule.id) {
      session = await activateScheduledSession(currentSchedule, /* @__PURE__ */ new Date());
    } else {
      const end = getScheduleBoundary(currentSchedule, "end_time", /* @__PURE__ */ new Date());
      if (end && end.getTime() <= Date.now()) {
        await expireSession();
        return;
      }
    }
  } else if (session?.scheduled_schedule_id) {
    const outcome = await scheduledSessionOutcome(session.scheduled_schedule_id);
    await finalizeActiveSession(outcome);
    await clearAllRules();
    await chrome.alarms.clear(ALARM_SESSION_EXPIRY);
    return;
  }
  if (!session) {
    await clearAllRules();
    await chrome.alarms.clear(ALARM_SESSION_EXPIRY);
    return;
  }
  const elapsed = Math.floor((Date.now() - new Date(session.started_at).getTime()) / 1e3);
  if (!session.scheduled_schedule_id && elapsed >= session.planned_duration_sec) {
    await expireSession();
    return;
  }
  const extensionId = chrome.runtime.id;
  let rules;
  if (session.mode === "lockdown") {
    rules = buildLockdownRules(
      session.whitelist_snapshot,
      temporaryAllows.map((entry) => entry.domain),
      extensionId
    );
  } else {
    rules = buildRules(
      session.blocklist_snapshot,
      session.whitelist_snapshot,
      temporaryAllows.map((entry) => entry.domain),
      extensionId
    );
  }
  await updateBlockingRules(rules);
  let remainingSec;
  if (session.scheduled_schedule_id && currentSchedule?.id === session.scheduled_schedule_id) {
    const end = getScheduleBoundary(currentSchedule, "end_time", /* @__PURE__ */ new Date());
    remainingSec = end ? Math.max(1, Math.ceil((end.getTime() - Date.now()) / 1e3)) : 1;
  } else {
    remainingSec = Math.max(1, session.planned_duration_sec - elapsed);
  }
  const remainingMs = remainingSec * 1e3;
  chrome.alarms.create(ALARM_SESSION_EXPIRY, {
    when: Date.now() + remainingMs
  });
  /* @__PURE__ */ (() => {
  })(
    `[FocusBlocker] Session active (${session.mode}). Expires in ${Math.round(remainingSec / 60)}m.`
  );
}
async function startSessionLocked(mode, duration_minutes, preset_id) {
  return withLock(async () => {
    const active = await storageGet("active_session");
    if (active) {
      throw new Error("A session is already active");
    }
    const blocklist = (await storageGet("blocklist") ?? []).map((d) => d.domain);
    const whitelist = (await storageGet("whitelist") ?? []).map((d) => d.domain);
    const newSession = {
      id: Math.random().toString(36).substring(2, 11),
      preset_id: preset_id ?? null,
      mode,
      started_at: (/* @__PURE__ */ new Date()).toISOString(),
      ended_at: null,
      planned_duration_sec: duration_minutes * 60,
      status: "active",
      blocklist_snapshot: blocklist,
      whitelist_snapshot: whitelist
    };
    await storageSet("active_session", newSession);
    await applyBlockingState();
    return null;
  });
}
async function stopSessionLocked() {
  return withLock(async () => {
    const active = await storageGet("active_session");
    if (active) {
      if (active.scheduled_schedule_id) {
        const schedules = await storageGet("schedules") ?? [];
        const schedule = schedules.find((item) => item.id === active.scheduled_schedule_id);
        const endMinutes = schedule ? timeToMinutes(schedule.end_time) : null;
        await setIfChanged(
          "schedule_suppressed_until",
          computeScheduleSuppression(endMinutes, active.planned_duration_sec, /* @__PURE__ */ new Date())
        );
      }
      await finalizeActiveSession("stopped");
      await setIfChanged("active_challenge", null);
      await applyBlockingState();
    }
    return null;
  });
}
async function handleBackgroundMessage(message) {
  const request = message;
  switch (request?.type) {
    case "session:start":
      return startSessionLocked(
        request.mode === "lockdown" ? "lockdown" : "blocklist",
        typeof request.duration_minutes === "number" ? request.duration_minutes : 0,
        request.preset_id
      );
    case "session:stop":
      return stopSessionLocked();
    case "session:expire":
      return withLock(async () => {
        await expireSession();
        return null;
      });
    default:
      throw new Error(`Unknown background message type`);
  }
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleBackgroundMessage(message).then((result) => {
    const response = { ok: true, result };
    sendResponse(response);
  }).catch((error) => {
    const response = {
      ok: false,
      error: error instanceof Error ? error.message : String(error)
    };
    sendResponse(response);
  });
  return true;
});
chrome.runtime.onInstalled.addListener(() => {
  /* @__PURE__ */ (() => {
  })("[FocusBlocker] Extension installed/updated. Applying state.");
  void requestReconcile();
});
chrome.runtime.onStartup.addListener(() => {
  /* @__PURE__ */ (() => {
  })("[FocusBlocker] Browser started. Applying state.");
  void requestReconcile();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  const relevantKeys = ["active_session", "blocklist", "whitelist", "temporary_allowlist", "schedules"];
  const hasRelevantChange = relevantKeys.some((k) => k in changes);
  if (!hasRelevantChange) return;
  /* @__PURE__ */ (() => {
  })("[FocusBlocker] Storage changed:", Object.keys(changes));
  void requestReconcile();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_SESSION_EXPIRY) {
    /* @__PURE__ */ (() => {
    })("[FocusBlocker] Session expiry alarm fired.");
    void requestReconcile();
  }
  if (alarm.name === ALARM_SCHEDULE_BOUNDARY) {
    /* @__PURE__ */ (() => {
    })("[FocusBlocker] Schedule boundary alarm fired.");
    void requestReconcile();
  }
  if (alarm.name === ALARM_TEMP_ALLOW_EXPIRY) {
    /* @__PURE__ */ (() => {
    })("[FocusBlocker] Temporary allow expired.");
    void requestReconcile();
  }
});
export {
  addDomainRules,
  applyBlockingState,
  buildLockdownRules,
  buildRules,
  computeScheduleSuppression,
  expireSession,
  getCurrentSchedule,
  getScheduleBoundary,
  isValidStoredDomain,
  migrateStrayActiveSession,
  requestReconcile,
  scheduleDays,
  scheduleRunsOn,
  startSessionLocked,
  stopSessionLocked,
  timeToMinutes,
  withLock
};
